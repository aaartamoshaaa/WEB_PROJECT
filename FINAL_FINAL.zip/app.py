# This Python file uses the following encoding: utf-8
from flask import Flask, request
from flask_ngrok import run_with_ngrok
import logging
import json
from org import get_address
from CONSTANTS import *

app = Flask(__name__)
run_with_ngrok(app)  # запуск приложения


# получаем имя
def get_first_name(req):
    # перебираем сущности
    for entity in req['request']['nlu']['entities']:
        # находим сущность с типом 'YANDEX.FIO'
        if entity['type'] == 'YANDEX.FIO':
            # Если есть сущность с ключом 'first_name', то возвращаем её значение.
            # Во всех остальных случаях возвращаем None.
            return entity['value'].get('first_name', None)


# показываем фотографии лицея
def show_photos(user_id, res, req):
    user_id = req['session']['user_id']
    res['response']['card'] = {}
    res['response']['card']['type'] = 'ImageGallery'
    res['response']['card']['title'] = 'Фотографии всех 3х корпусов.'
    res['response']['card']['items'] = [{'image_id': i} for i in LYCEUM_IMAGES]
    res['response']['text'] = 'Фотографии всех 3х корпусов.'


# отсылаем историю лицея
def show_information(user_id, res, req):
    user_id = req['session']['user_id']

    with open('some_information.txt', 'r', encoding='utf-8') as f:
        ff = f.read()

    res['response']['text'] = ff


# директор
def show_main_person(user_id, res, req):
    user_id = req['session']['user_id']

    with open('director.txt', 'r', encoding='utf-8') as f:
        ff = f.read()

    res['response']['card'] = {}
    res['response']['card']['type'] = 'BigImage'
    res['response']['card']['title'] = ff
    res['response']['card']['image_id'] = DIRECTOR_IMAGE
    res['response']['text'] = ' '


# показываем адреса
def show_adress(user_id, res, req):
    user_id = req['session']['user_id']
    sessionStorage[user_id]['PHASE'] = 3

    res['response']['text'] = f"Первый корпус - {get_address('Лицей 1580, корпус 1', address_ll1)}\n" \
                              f"Второй корпус - {get_address('Лицей 1580, корпус 2', address_ll2)}\n" \
                              f"Третий корпус - {get_address('Лицей 1580, корпус 3', address_ll3)}"


# подсказки-кнопки
def get_suggests(user_id):
    session = sessionStorage[user_id]

    # Выбираем все подсказки из массива.
    if session['PHASE'] != 3:
        suggests = [
            {'title': suggest,
             'hide': True,
             'payload': {'btn': suggest_num + 1}
             }
            for suggest_num, suggest in enumerate(session['suggests'])
        ]
    else:
        # особые подсказки-кнопки для адреса
        suggests = [
            {
                "title": "Покажи первый корпус на карте",
                "url": ADDRESS1_MAP,
                "payload": {'btn': 7},
                "hide": True
            },
            {
                "title": "Покажи второй корпус на карте",
                "url": ADDRESS2_MAP,
                "payload": {'btn': 7},
                "hide": True
            },
            {
                "title": "Покажи третий корпус на карте",
                "url": ADDRESS3_MAP,
                "payload": {'btn': 7},
                "hide": True
            },
            {
                "title": "Шаг назад",
                "payload": {'btn': 8},
                "hide": True
            }
        ]

    return suggests


# состояние сессии
STATE = {
    1: {1: 1},
    2: {2: 2},
    3: {3: 3},
    4: {4: 4}
}

sessionStorage = {}


# главная функция
@app.route('/post', methods=['POST'])
def main():
    logging.info('Request: %r', request.json)
    response = {
        'session': request.json['session'],
        'version': request.json['version'],
        'response': {
            'end_session': False
        }
    }
    handle_dialog(response, request.json)
    logging.info('Response: %r', response)
    return json.dumps(response)


# функция диалога
def handle_dialog(res, req):
    user_id = req['session']['user_id']

    # новый пользователь
    if req['session']['new']:
        res['response']['text'] = 'Здравствуйте, Представьтесь пожалуйста.'
        sessionStorage[user_id] = {
            'first_name': None,  # здесь будет храниться имя
            'suggests': [
                "Показать фотографии лицея.",
                "Адрес лицея.",
                "Главный человек лицея.",
                "История лицея.",
                "Попрощаться."
            ],
            'PHASE': 0
        }

        return

    # не нашли имя пользователя, просим ещё раз ввести
    if sessionStorage[user_id]['first_name'] is None:
        first_name = get_first_name(req)
        if first_name is None:
            res['response']['text'] = 'Прошу прощения, но я не узнала такое имя. Повторите, ' \
                                      'пожалуйста.'
            return
        # нашли имя и приветсвуем
        else:
            sessionStorage[user_id]['first_name'] = first_name
            sessionStorage[user_id]['PHASE'] = 1
            res['response']['text'] = f"Приятно познакомиться,  \
                                      {sessionStorage[user_id]['first_name'].capitalize()}.\n \
                                      Вот что я умею:\n \
                                      -Показать фотографии лицея.\n \
                                      -Адрес лицея.\n \
                                      -Главный человек лицея.\n \
                                      -История лицея."
            res['response']['buttons'] = get_suggests(user_id)

            return

    # подключаем кнопки к обработчикам
    try:
        sessionStorage[user_id]['BTN'] = req['request']['payload']['btn']
        event = sessionStorage[user_id]['BTN']

        if event == 1:
            show_photos(user_id, res, req)


        elif event == 2:
            show_adress(user_id, res, req)


        elif event == 3:
            show_main_person(user_id, res, req)


        elif event == 4:
            show_information(user_id, res, req)

        elif event == 7:
            pass

        # выходим из адреса
        elif event == 8:
            sessionStorage[user_id]['PHASE'] = 1

        # прощаемся с пользователем
        elif event == 5:
            res['response']['end_session'] = True
            res['response']['text'] = 'До свидания.'

        # отправляем кнопки
        res['response']['buttons'] = get_suggests(user_id)
        if not res['response']['text']:
            res['response']['text'] = ' '
    except KeyError:
        res['response']['text'] = "Пожалуйста, выберите команду из списка."
        res['response']['buttons'] = get_suggests(user_id)


if __name__ == '__main__':
    app.run()

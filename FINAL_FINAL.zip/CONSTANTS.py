DIRECTOR_IMAGE = '1540737/e33dd8314276d8386745'

LYCEUM_IMAGES = ['965417/2950b3af3740ffc79a74',
                 '997614/53f1427c9cf51fdc0672',
                 '1540737/56420d64a3255e52b1c8',
                 '1030494/dd7df0876e0dec52664a',
                 '1030494/bf4a6a3542af0c76e972',
                 '965417/1e0542872ca010d75143']

ADDRESS1_MAP = "https://yandex.ru/maps/?mode=search&text=%D0%BB%D0%B8%D1%86%D0%B5%D0%B9%201580%20" \
               "%D0%BA%D0%BE%D1%80%D0%BF%D1%83%D1%81%201"
ADDRESS2_MAP = "https://yandex.ru/maps/?mode=search&text=%D0%BB%D0%B8%D1%86%D0%B5%D0%B9%201580%20" \
               "%D0%BA%D0%BE%D1%80%D0%BF%D1%83%D1%81%202"
ADDRESS3_MAP = "https://yandex.ru/maps/?mode=search&text=%D0%BB%D0%B8%D1%86%D0%B5%D0%B9%201580%20" \
               "%D0%BA%D0%BE%D1%80%D0%BF%D1%83%D1%81%203"

address_ll1 = "37.613078, 55.641513"
address_ll2 = "37.613125, 55.642449"
address_ll3 = "37.596641, 55.717615"

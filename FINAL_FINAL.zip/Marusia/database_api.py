import re
from flask_sqlalchemy import SQLAlchemy
from typing import Union
from flask import Flask
from re import A, match

flask_db = Flask(__name__)

flask_db.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
flask_db.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


database = SQLAlchemy(flask_db)


class Lessons(database.Model):
    __tablename__ = "lessons"
    id = database.Column(database.Integer, primary_key=True)
    lesson_number = database.Column(database.Integer)
    subject = database.Column(database.String)
    day_of_week = database.Column(database.Integer)
    teacher = database.Column(database.String)
    cabinet = database.Column(database.String)
    class_group = database.Column(database.String)


WEEKDAYS = {
    1: "понедельник",
    2: "вторник",
    3: "среда",
    4: "четверг",
    5: "пятница",
    6: "суббота",
    "понедельник": 1,
    "вторник": 2,
    "среда": 3,
    "четверг": 4,
    "пятница": 5,
    "суббота": 6,
}


def __by_day_for_group(day: int, group: str):
    answer = []
    data = Lessons.query.filter_by(class_group=group, day_of_week=day).all()
    if not data:
        return None

    for lesson in data:
        answer.append(
            {
                "lesson_number": lesson.lesson_number,
                "subject": lesson.subject,
                "teacher": lesson.teacher,
                "cabinet": lesson.cabinet,
            }
        )
    return answer


def __is_whole_class(group):
    return match(r"10.", group).group() == group


def __is_group(group):
    return match(r"10.[1-2]", group).group() == group


def by_day(day: Union[int, str], group: str):
    """Расписание на день для конкретного класса

    Args:
        day (Union[int, str]): номер дня в недели по русской системе или название в ИП
        group (str): [description]
    """
    if isinstance(day, str):
        day = WEEKDAYS.get(day)
    if day is None or day not in range(1, 7):
        return None
    if __is_whole_class(group):
        # get for group class
        answer = {group + "1": [], group + "2": []}

        data = __by_day_for_group(day, group + "1")
        if not data:
            return None

        answer[group + "1"] = data

        data = __by_day_for_group(day, group + "2")
        if not data:
            return None

        answer[group + "2"] = data

        return answer
    elif __is_group(group):
        return __by_day_for_group(day, group)


def by_day_range(start: Union[int, str], end: Union[int, str], group: str):
    """Возвращает расписание для диапозона

    Args:
        start (Union[int, str]): номер дня в недели по русской системе или название в ИП
        end (Union[int, str]): номер дня в недели по русской системе или название в ИП
        group (str): класс или группа
    """
    if isinstance(start, str):
        start = WEEKDAYS.get(start)
    if start is None or start not in range(1, 7):
        return None
    if isinstance(end, str):
        end = WEEKDAYS.get(end)
    if end is None and end not in range(1, 7):
        return None

    if end < start:
        return None

    answer = {}
    for i in range(start, end + 1):
        answer[WEEKDAYS.get(i)] = by_day(i, group)

    return answer


def week(group: str):
    """Возвращает расписание на неделю для группы / класса

    Args:
        group (str): Группа или класс, должна иметь формат 10.[1-2]?
    """
    return by_day_range(1, 6, group)


def lesson_in_day(day: Union[int, str], number: int, group: str):
    """Возвращает урок в день для класса/группы

    Args:
        day (Union[int, str]): номер дня в недели по русской системе или название в ИП
        number (int): номер урока
        group (str): класс или группа
    """
    if isinstance(day, str):
        day = WEEKDAYS.get(day)
    if day is None or day not in range(1, 7):
        return None
    if number not in range(0, 10):
        return None

    if __is_whole_class(group):
        lesson1 = Lessons.query.filter_by(
            day_of_week=day, lesson_number=number, class_group=group + "1"
        ).first()
        lesson2 = Lessons.query.filter_by(
            day_of_week=day, lesson_number=number, class_group=group + "2"
        ).first()
        answer = {}
        if lesson1 is None and lesson2 is None:
            return None
        if lesson1 is not None:
            answer[group + "1"] = {
                "lesson_number": lesson1.lesson_number,
                "subject": lesson1.subject,
                "teacher": lesson1.teacher,
                "cabinet": lesson1.cabinet,
            }
        if lesson2 is not None:
            answer[group + "2"] = {
                "lesson_number": lesson2.lesson_number,
                "subject": lesson2.subject,
                "teacher": lesson2.teacher,
                "cabinet": lesson2.cabinet,
            }
        return answer
    elif __is_group(group):
        lesson = Lessons.query.filter_by(
            day_of_week=day, lesson_number=number, class_group=group
        ).first()
        return {
            "lesson_number": lesson.lesson_number,
            "subject": lesson.subject,
            "teacher": lesson.teacher,
            "cabinet": lesson.cabinet,
        }


def find_teacher(day: Union[str, int], search_teacher: str):
    if isinstance(day, str):
        day = WEEKDAYS.get(day)
    if day is None or day not in range(1, 7):
        return None

    lessons = filter(
        lambda lesson: search_teacher in lesson.teacher,
        Lessons.query.filter_by(day_of_week=day).all(),
    )
    cabinets = []
    for lesson in lessons:
        x = {"cabinet": lesson.cabinet, "lesson_number": lesson.lesson_number}
        if x not in cabinets:
            cabinets.append(x)
    if not cabinets:
        return None
    return cabinets


import json

with open("monday.json", "w") as f:
    json.dump(by_day(1, "10е"), f, ensure_ascii=False)

with open("mondayE1.json", "w") as f:
    json.dump(by_day(1, "10е1"), f, ensure_ascii=False)

with open("monday-friday.json", "w") as f:
    json.dump(by_day_range(1, 5, "10е"), f, ensure_ascii=False)

with open("week.json", "w") as f:
    json.dump(week("10е1"), f, ensure_ascii=False)

with open("ivanov.json", "w") as f:
    json.dump(find_teacher(4, "Иванов"), fp=f, ensure_ascii=False)
